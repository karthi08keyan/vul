<?php

define( 'DVWA_WEB_PAGE_TO_ROOT', '' );
require_once DVWA_WEB_PAGE_TO_ROOT . 'dvwa/includes/dvwaPage.inc.php';

dvwaPageStartup( array( 'authenticated', 'phpids' ) );

$page = dvwaPageNewGrab();
$page[ 'title' ]   = 'Welcome' . $page[ 'title_separator' ].$page[ 'title' ];
$page[ 'page_id' ] = 'home';

$page[ 'body' ] .= "
<div class=\"body_padded\">
	<h1>Welcome  Vulnerable Web Application!</h1>
	<p style='font-size: 30px;'>Karthikeyan_K</p>
	<p>Msc Cyper security 2021-2023 </p> <br/>
	<p style='font-size: 30px;'>Sethupathy_K</p>
	<p>Msc Cyper security 2021-2023 </p>
	<hr />
	<br />

	<h2>General Instructions</h2>
	<p>security testing is used to bulid a secure system but it has been ignored for a long time </p>
	<p>It is of immaculate importance thes days.In today's world,privacy and security have been assigned foremost importance.Therfore,it is highly recommended to look forward for data</p>
	<p>and opreation security in software applications,which demands urgent attation but it is rather ignored.Therefore, our objective is to conduct vulnerability assessment for</p> 
	<b>Vulnerable Web Application</b>
	<p>we as a team devloped the website to gather information that is what are all the possible ways to penetrate into this system</p>
	
	<hr />
	<br />

	
</div>";

dvwaHtmlEcho( $page );

?>
